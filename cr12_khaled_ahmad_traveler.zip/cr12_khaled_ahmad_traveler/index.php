<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package cr12_khaled_ahmad_traveler
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">
	<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li  data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li  data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="https://bizplan.webulous.in/wp-content/uploads/2016/11/home-slider1.png" alt="First slide">
      <div class="carousel-caption d-none d-md-block" style="color: black">
    <h5><?php bloginfo('name'); ?></h5>
    <p><?php bloginfo('description'); ?></p>
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="https://bizplan.webulous.in/wp-content/uploads/2016/11/home-slider3-1.png" alt="Second slide">
        <div class="carousel-caption d-none d-md-block" style="color: black">
    <h5><?php bloginfo('name'); ?></h5>
    <p><?php bloginfo('description'); ?></p>
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="https://bizplan.webulous.in/wp-content/uploads/2016/11/home-slider2-1.png" alt="Third slide">
        <div class="carousel-caption d-none d-md-block" style="color: black">
    <h5><?php bloginfo('name'); ?></h5>
    <p><?php bloginfo('description'); ?></p>
  </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
      </section>
      <div class="album py-5 bg-light">
      	<div class="container">
      <div class="row">
          	<?php if ( have_posts() ) : ?>

				<?php if ( is_home() && ! is_front_page() ) : ?>
					
							<?php endif; ?>

					<?php
							// Start the loop.
					while ( have_posts() ) : the_post();
				?>
				<div class="col-md-4">
				<div class="card mb-4 box-shadow">
				 <?php if(has_post_thumbnail()) : ?>
				 	 <img class="card-img-top" data-src="holder.js/100px225?theme=thumb&amp;bg=55595c&amp;fg=eceeef&amp;text=Thumbnail" alt="Thumbnail [100%x225]" style="height: 225px; width: 100%; display: block;" src=<?php the_post_thumbnail();?>
				<?php endif;?>
				  <div class="card-body">
				                  
				    <a style="color: black" href="<?php the_permalink();?>" class="card-title" >  <?php the_title(); ?> </a>
				    <p class="card-text"><?php the_excerpt();// blog post content ?></p>
				    <hr>
				    <a  href="<?php echo get_author_posts_url(get_the_author_meta('ID')); // href to author posts ?>" class="card-link"><?php the_author(); // blog post author ?></a>
				    <hr>
				    <p class="text-center"> <?php the_date(); // blog post date ?></p>
				  </div>

				    
				 
				     
				   
				</div>
				</div>             
				            
				
				<?php
							// End the loop.
							endwhile;
				?>

				<?php else:  ?>
				<p><?php echo "‘No Posts Found’"; ?></p>
				<?php endif; ?>
				
						</main><!-- #main -->
					</div>
<?php

get_footer();
?>