<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cr12_khaled_ahmad_traveler
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>

<style >
	.col-md-4 {
		float: left;
		font-size: 14px;
		padding-top: 10px;

	}

	.col-md-4 h2 {
		font-size: 18px;
		color: #5a9fc3; 
	}
	.widget-title {
		width: 200px;
	}

	.col-md-4 ul{
		float: left;
		margin-left: 0;
		width: 200px;
		text-decoration: none;
		color: black;
	}
	.col-md-4 a{
		color: black;
	}
</style>
        <aside class="col-md-4 blog-sidebar" style="width: 100%">
          <?php dynamic_sidebar( 'sidebar-1' ); ?>
         
        </aside><!-- /.blog-sidebar -->

      </div><!-- /.row -->

    </main>


